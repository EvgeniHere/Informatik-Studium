#include <stdio.h>

int main() {
	int zahl;
	while(scanf("%d", &zahl) != EOF && zahl >= 0) {
		printf("OKT: %o HEX: %x\n", zahl, zahl);
	}
	return 0;
}
