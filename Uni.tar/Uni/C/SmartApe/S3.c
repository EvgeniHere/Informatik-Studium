#include<stdio.h>

int main() {
	printf("Aller guten Dinge sind 3.\nPi ist ungefaehr 3.141593.\n");
	return 1;
}
