#include <stdio.h>
#include <limits.h>
#include <float.h>

int main() {
	printf("CHAR_MIN: %d\n", CHAR_MIN);
	printf("CHAR_MAX: %d\n", CHAR_MAX);
	printf("INT_MIN: %d\n", INT_MIN);
	printf("INT_MAX: %d\n", INT_MAX);
	printf("FLT_MIN: %f\n", FLT_MIN);
	printf("FLT_MAX: %f\n", FLT_MAX);
	printf("DBL_MIN: %f\n", DBL_MIN);
	printf("DBL_MAX: %f\n", DBL_MAX);
	return 0;
}

/*
	i oder d int
	f, e oder g double
	c oder s char
*/
