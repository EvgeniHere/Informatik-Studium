#include <stdio.h>

int main() {
	printf("Er kam lässig heran und sagte nur \"Na, wie geht's?\".\nKommentare beginnen mit /* und enden mit */. Verwechseln Sie das bitte nicht mit \\* bzw. *\\!\n");
	return 0;
}
