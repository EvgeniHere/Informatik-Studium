#include <stdio.h>

int main() {
	int num = 'A';
	
	while(num <= 'z') {
		printf("%c", num);
		num = num + 1;
	}
	printf("\n");
	return 0;
}
