int main() {
	return 256;
}

//Compile: gcc first.c -o firstOutput -Wall -std=c11
//			./firstOutput
//			echo $?
