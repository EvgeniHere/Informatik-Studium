containsList :: [Int] -> Int -> Bool
containsList [] n = False
containsList (x:xs) n = if (x == n) then True else containsList xs n
