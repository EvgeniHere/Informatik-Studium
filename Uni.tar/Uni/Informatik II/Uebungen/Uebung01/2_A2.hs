import Data.Char (toLower)

countList :: [Char] -> Char -> Int
countList xs c = countChar xs c 0

countChar :: [Char] -> Char -> Int -> Int
countChar [] c n = n
countChar (x:xs) c n = if (toLower x == toLower c) then countChar xs c (n+1) else countChar xs c n
