mysum :: Int -> Int
mysum x
  | x > 1 = 2 * x - 1 + y
  | otherwise = 2 * x - 1
  where y = mysum (x-1)

square :: Int -> Int
square n
  | n < 0 = square (n*(-1))
  | n == 0 = 0
  | otherwise = x
  where x = mysum n
