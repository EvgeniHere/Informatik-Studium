output_row :: (Int -> Int) -> Int -> String
output_row f n = show n ++ ":" ++ show (f n) ++ "\n"

tableInt :: (Int -> Int) -> [Int] -> String
tableInt f [] = ""
tableInt f (x:xs) = output_row f x ++ tableInt f xs


--needed

mysum :: Int -> Int
mysum x
  | x > 1 = 2 * x - 1 + y
  | otherwise = 2 * x - 1
  where y = mysum (x-1)

square :: Int -> Int
square n
  | n < 0 = square (n*(-1))
  | n == 0 = 0
  | otherwise = x
  where x = mysum n
  
quadratic :: (Int, Int, Int) -> Int -> Int
quadratic (a, b, c) x = a*x*x + b*x + c
