quadratic :: (Int, Int, Int) -> Int -> Int
quadratic (a, b, c) x = a*x*x + b*x + c
