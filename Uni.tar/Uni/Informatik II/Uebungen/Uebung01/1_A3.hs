sumList :: [Int] -> Int
sumList list = addition list 0 (length list - 1)

addition :: [Int] -> Int -> Int -> Int
addition list sum n
  | n > 0 = sum + x + y
  | n == 0 = sum + x
  where x = list !! n
        y = addition list sum (n-1)
        
foldList :: (Double -> Double -> Double) -> [Double] -> Double
foldList f [x] = x
foldList f (x:xs) = f x (foldList f xs)
