public class DayTrader {

    public DayTrader(double p) {
	price = p;
    }

    // setter ----------------------------------------------
    public void setPrice(double p) {
	price = p;
    }

    // private ---------------------------------------------
    private double price;

}
